import React from 'react';

const Doctors = () => {
  return (
    <div>
      Doctors Page
    </div>
  );
};

export default Doctors;
