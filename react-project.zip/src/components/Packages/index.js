import React from 'react';

const Packages = () => {
  return (
    <div>
      Packages page
    </div>
  );
};

export default Packages;
