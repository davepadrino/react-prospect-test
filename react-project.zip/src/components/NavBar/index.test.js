import React from 'react';
import renderer from 'react-test-renderer';
import NavBar from './index';

describe('NavBar', () => {

  it('NavBar should be defined', () => {
    expect(NavBar).toBeDefined();
  });


});
